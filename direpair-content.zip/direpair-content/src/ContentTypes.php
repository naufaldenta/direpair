<?php

declare(strict_types=1);

namespace Direpair\Content;

final class ContentTypes
{
    /**
     * @return array<string, array{label: string, singular: string, rest_base: string, menu_icon: string}>
     */
    public static function postTypes(): array
    {
        return [
            'direpair_service' => [
                'label' => 'Services',
                'singular' => 'Service',
                'rest_base' => 'services',
                'menu_icon' => 'dashicons-admin-tools',
            ],
            'direpair_problem' => [
                'label' => 'Problems',
                'singular' => 'Problem',
                'rest_base' => 'problems',
                'menu_icon' => 'dashicons-search',
            ],
            'direpair_location' => [
                'label' => 'Locations',
                'singular' => 'Location',
                'rest_base' => 'locations',
                'menu_icon' => 'dashicons-location-alt',
            ],
            'direpair_tech' => [
                'label' => 'Technicians',
                'singular' => 'Technician',
                'rest_base' => 'technicians',
                'menu_icon' => 'dashicons-businessperson',
            ],
            'direpair_case' => [
                'label' => 'Repair Cases',
                'singular' => 'Repair Case',
                'rest_base' => 'repair-cases',
                'menu_icon' => 'dashicons-clipboard',
            ],
            'direpair_price' => [
                'label' => 'Pricing Guides',
                'singular' => 'Pricing Guide',
                'rest_base' => 'pricing-guides',
                'menu_icon' => 'dashicons-money-alt',
            ],
            'direpair_faq' => [
                'label' => 'FAQs',
                'singular' => 'FAQ',
                'rest_base' => 'faqs',
                'menu_icon' => 'dashicons-editor-help',
            ],
            'direpair_warranty' => [
                'label' => 'Warranty Policies',
                'singular' => 'Warranty Policy',
                'rest_base' => 'warranties',
                'menu_icon' => 'dashicons-shield-alt',
            ],
            'direpair_article' => [
                'label' => 'Knowledge Articles',
                'singular' => 'Knowledge Article',
                'rest_base' => 'knowledge-articles',
                'menu_icon' => 'dashicons-welcome-learn-more',
            ],
            'direpair_policy' => [
                'label' => 'Legal Policies',
                'singular' => 'Legal Policy',
                'rest_base' => 'policies',
                'menu_icon' => 'dashicons-privacy',
            ],
        ];
    }

    /**
     * @return array<string, array{label: string, singular: string, rest_base: string, post_types: list<string>}>
     */
    public static function taxonomies(): array
    {
        $contentPostTypes = array_keys(self::postTypes());

        return [
            'direpair_device' => [
                'label' => 'Device Categories',
                'singular' => 'Device Category',
                'rest_base' => 'device-categories',
                'post_types' => $contentPostTypes,
            ],
            'direpair_brand' => [
                'label' => 'Brands',
                'singular' => 'Brand',
                'rest_base' => 'brands',
                'post_types' => $contentPostTypes,
            ],
            'direpair_symptom' => [
                'label' => 'Symptoms',
                'singular' => 'Symptom',
                'rest_base' => 'symptoms',
                'post_types' => $contentPostTypes,
            ],
            'direpair_method' => [
                'label' => 'Service Methods',
                'singular' => 'Service Method',
                'rest_base' => 'service-methods',
                'post_types' => ['direpair_service', 'direpair_location', 'direpair_price'],
            ],
            'direpair_city' => [
                'label' => 'Service Areas',
                'singular' => 'Service Area',
                'rest_base' => 'service-areas',
                'post_types' => ['direpair_service', 'direpair_location', 'direpair_case'],
            ],
        ];
    }

    public static function register(): void
    {
        foreach (self::postTypes() as $postType => $definition) {
            register_post_type($postType, [
                'labels' => self::postTypeLabels($definition['label'], $definition['singular']),
                'public' => true,
                'publicly_queryable' => false,
                'exclude_from_search' => true,
                'show_ui' => true,
                'show_in_menu' => true,
                'show_in_nav_menus' => false,
                'show_in_rest' => true,
                'rest_base' => $definition['rest_base'],
                'has_archive' => false,
                'rewrite' => false,
                'menu_icon' => $definition['menu_icon'],
                'supports' => [
                    'title',
                    'editor',
                    'excerpt',
                    'thumbnail',
                    'revisions',
                    'author',
                    'custom-fields',
                ],
            ]);
        }

        foreach (self::taxonomies() as $taxonomy => $definition) {
            register_taxonomy($taxonomy, $definition['post_types'], [
                'labels' => self::taxonomyLabels($definition['label'], $definition['singular']),
                'public' => true,
                'publicly_queryable' => false,
                'show_ui' => true,
                'show_admin_column' => true,
                'show_in_rest' => true,
                'rest_base' => $definition['rest_base'],
                'hierarchical' => true,
                'rewrite' => false,
            ]);
        }
    }

    public static function isManaged(string $postType): bool
    {
        return isset(self::postTypes()[$postType]);
    }

    /**
     * @return array<string, string>
     */
    private static function postTypeLabels(string $plural, string $singular): array
    {
        return [
            'name' => $plural,
            'singular_name' => $singular,
            'add_new_item' => sprintf('Add New %s', $singular),
            'edit_item' => sprintf('Edit %s', $singular),
            'new_item' => sprintf('New %s', $singular),
            'view_item' => sprintf('View %s', $singular),
            'search_items' => sprintf('Search %s', $plural),
            'not_found' => sprintf('No %s found', mb_strtolower($plural)),
            'all_items' => sprintf('All %s', $plural),
        ];
    }

    /**
     * @return array<string, string>
     */
    private static function taxonomyLabels(string $plural, string $singular): array
    {
        return [
            'name' => $plural,
            'singular_name' => $singular,
            'search_items' => sprintf('Search %s', $plural),
            'all_items' => sprintf('All %s', $plural),
            'edit_item' => sprintf('Edit %s', $singular),
            'update_item' => sprintf('Update %s', $singular),
            'add_new_item' => sprintf('Add New %s', $singular),
            'new_item_name' => sprintf('New %s Name', $singular),
            'menu_name' => $plural,
        ];
    }
}
