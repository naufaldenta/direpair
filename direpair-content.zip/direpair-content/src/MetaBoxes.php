<?php

declare(strict_types=1);

namespace Direpair\Content;

final class MetaBoxes
{
    private const NONCE_ACTION = 'direpair_content_meta';
    private const NONCE_NAME = 'direpair_content_nonce';

    public static function register(): void
    {
        foreach (array_keys(ContentTypes::postTypes()) as $postType) {
            add_meta_box(
                'direpair-content-fields',
                'Direpair Content Fields',
                [self::class, 'render'],
                $postType,
                'normal',
                'high'
            );
        }
    }

    public static function render(\WP_Post $post): void
    {
        wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME);

        echo '<div class="direpair-content-fields">';

        foreach (MetaFields::forPostType($post->post_type) as $name => $definition) {
            self::renderField($post, $name, $definition);
        }

        echo '</div>';
    }

    public static function save(int $postId, \WP_Post $post): void
    {
        if (! ContentTypes::isManaged($post->post_type)) {
            return;
        }

        if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
            return;
        }

        $nonce = isset($_POST[self::NONCE_NAME])
            ? sanitize_text_field(wp_unslash($_POST[self::NONCE_NAME]))
            : '';

        if ($nonce === '' || ! wp_verify_nonce($nonce, self::NONCE_ACTION)) {
            return;
        }

        if (! current_user_can('edit_post', $postId)) {
            return;
        }

        $submitted = isset($_POST['direpair_meta']) && is_array($_POST['direpair_meta'])
            ? wp_unslash($_POST['direpair_meta'])
            : [];

        foreach (MetaFields::forPostType($post->post_type) as $name => $definition) {
            if ($name === 'external_uuid') {
                continue;
            }

            $value = self::sanitizeSubmittedValue($submitted[$name] ?? null, $definition['type']);
            update_post_meta($postId, MetaFields::key($name), $value);
        }

        self::ensureExternalUuid($postId);
    }

    public static function ensureExternalUuid(int $postId): void
    {
        if (wp_is_post_revision($postId) || wp_is_post_autosave($postId)) {
            return;
        }

        $postType = get_post_type($postId);

        if (! is_string($postType) || ! ContentTypes::isManaged($postType)) {
            return;
        }

        $key = MetaFields::key('external_uuid');

        if ((string) get_post_meta($postId, $key, true) === '') {
            update_post_meta($postId, $key, wp_generate_uuid4());
        }
    }

    /**
     * @param array{label: string, type: string, control?: string, description?: string} $definition
     */
    private static function renderField(\WP_Post $post, string $name, array $definition): void
    {
        $key = MetaFields::key($name);
        $value = get_post_meta($post->ID, $key, true);
        $control = $definition['control'] ?? 'text';
        $fieldId = 'direpair-meta-'.sanitize_html_class($name);
        $fieldName = sprintf('direpair_meta[%s]', esc_attr($name));

        echo '<div class="direpair-field">';
        printf('<label for="%s"><strong>%s</strong></label>', esc_attr($fieldId), esc_html($definition['label']));

        if ($control === 'checkbox') {
            printf('<input type="hidden" name="%s" value="0">', $fieldName);
            printf(
                '<label><input id="%s" type="checkbox" name="%s" value="1" %s> Enabled</label>',
                esc_attr($fieldId),
                $fieldName,
                checked((bool) $value, true, false)
            );
        } elseif ($control === 'textarea' || $control === 'textarea_list') {
            $displayValue = is_array($value) ? implode("\n", $value) : (string) $value;
            printf(
                '<textarea id="%s" name="%s" rows="4" class="widefat">%s</textarea>',
                esc_attr($fieldId),
                $fieldName,
                esc_textarea($displayValue)
            );
        } else {
            $displayValue = is_array($value) ? implode(',', $value) : (string) $value;
            $inputType = match ($control) {
                'url' => 'url',
                'date' => 'date',
                'readonly' => 'text',
                default => in_array($definition['type'], ['integer', 'number'], true) ? 'number' : 'text',
            };
            $step = $definition['type'] === 'number' ? ' step="0.01"' : '';
            $readonly = $control === 'readonly' ? ' readonly' : '';
            printf(
                '<input id="%s" type="%s" name="%s" value="%s" class="widefat"%s%s>',
                esc_attr($fieldId),
                esc_attr($inputType),
                $fieldName,
                esc_attr($displayValue),
                $step,
                $readonly
            );
        }

        if (isset($definition['description'])) {
            printf('<small>%s</small>', esc_html($definition['description']));
        }

        echo '</div>';
    }

    private static function sanitizeSubmittedValue(mixed $value, string $type): mixed
    {
        return match ($type) {
            'boolean' => MetaFields::sanitizeBoolean($value),
            'integer' => absint($value),
            'number' => MetaFields::sanitizeNumber($value),
            'array_integer' => MetaFields::sanitizeIntegerArray(
                is_array($value) ? $value : (preg_split('/\s*,\s*/', (string) $value) ?: [])
            ),
            'array_string' => MetaFields::sanitizeStringArray(
                is_array($value) ? $value : (preg_split('/\R/', (string) $value) ?: [])
            ),
            default => sanitize_text_field((string) $value),
        };
    }
}
