<?php

declare(strict_types=1);

namespace Direpair\Content;

final class MetaFields
{
    public const PREFIX = '_direpair_';

    /**
     * @return array<string, array{label: string, type: string, control?: string, default?: mixed, post_types?: list<string>, description?: string}>
     */
    public static function definitions(): array
    {
        $allPostTypes = array_keys(ContentTypes::postTypes());
        $serviceContent = ['direpair_service', 'direpair_problem', 'direpair_price'];

        return [
            'external_uuid' => [
                'label' => 'External UUID',
                'type' => 'string',
                'control' => 'readonly',
                'post_types' => $allPostTypes,
            ],
            'is_demo' => [
                'label' => 'Demo content',
                'type' => 'boolean',
                'control' => 'checkbox',
                'default' => false,
                'post_types' => $allPostTypes,
                'description' => 'Demo content is excluded from trusted production output.',
            ],
            'is_verified' => [
                'label' => 'Business-verified content',
                'type' => 'boolean',
                'control' => 'checkbox',
                'default' => false,
                'post_types' => $allPostTypes,
            ],
            'noindex' => [
                'label' => 'Noindex',
                'type' => 'boolean',
                'control' => 'checkbox',
                'default' => false,
                'post_types' => $allPostTypes,
            ],
            'seo_title' => [
                'label' => 'SEO title',
                'type' => 'string',
                'post_types' => $allPostTypes,
            ],
            'seo_description' => [
                'label' => 'SEO description',
                'type' => 'string',
                'control' => 'textarea',
                'post_types' => $allPostTypes,
            ],
            'hero_eyebrow' => [
                'label' => 'Hero eyebrow',
                'type' => 'string',
                'post_types' => $allPostTypes,
            ],
            'hero_title' => [
                'label' => 'Hero title override',
                'type' => 'string',
                'post_types' => $allPostTypes,
            ],
            'hero_summary' => [
                'label' => 'Hero summary',
                'type' => 'string',
                'control' => 'textarea',
                'post_types' => $allPostTypes,
            ],
            'primary_cta_label' => [
                'label' => 'Primary CTA label',
                'type' => 'string',
                'post_types' => $allPostTypes,
            ],
            'primary_cta_url' => [
                'label' => 'Primary CTA URL',
                'type' => 'string',
                'control' => 'url',
                'post_types' => $allPostTypes,
            ],
            'quick_answer' => [
                'label' => 'Quick answer',
                'type' => 'string',
                'control' => 'textarea',
                'post_types' => ['direpair_service', 'direpair_problem', 'direpair_article'],
            ],
            'price_from' => [
                'label' => 'Public price from',
                'type' => 'number',
                'post_types' => $serviceContent,
            ],
            'price_to' => [
                'label' => 'Public price to',
                'type' => 'number',
                'post_types' => $serviceContent,
            ],
            'diagnosis_fee' => [
                'label' => 'Diagnosis fee',
                'type' => 'number',
                'post_types' => $serviceContent,
            ],
            'currency' => [
                'label' => 'Currency',
                'type' => 'string',
                'default' => 'IDR',
                'post_types' => $serviceContent,
            ],
            'turnaround_min_days' => [
                'label' => 'Minimum turnaround days',
                'type' => 'integer',
                'post_types' => $serviceContent,
            ],
            'turnaround_max_days' => [
                'label' => 'Maximum turnaround days',
                'type' => 'integer',
                'post_types' => $serviceContent,
            ],
            'pricing_disclaimer' => [
                'label' => 'Pricing disclaimer',
                'type' => 'string',
                'control' => 'textarea',
                'post_types' => $serviceContent,
            ],
            'warranty_summary' => [
                'label' => 'Warranty summary',
                'type' => 'string',
                'control' => 'textarea',
                'post_types' => ['direpair_service', 'direpair_problem', 'direpair_price', 'direpair_warranty'],
            ],
            'supported_models' => [
                'label' => 'Supported models',
                'type' => 'array_string',
                'control' => 'textarea_list',
                'post_types' => ['direpair_service', 'direpair_problem'],
                'description' => 'One model per line.',
            ],
            'service_methods' => [
                'label' => 'Service methods',
                'type' => 'array_string',
                'control' => 'textarea_list',
                'post_types' => ['direpair_service', 'direpair_location', 'direpair_price'],
                'description' => 'One method per line: drop-off, pickup, or home-service.',
            ],
            'related_problem_ids' => [
                'label' => 'Related problem IDs',
                'type' => 'array_integer',
                'control' => 'csv_integer',
                'post_types' => ['direpair_service'],
            ],
            'related_service_ids' => [
                'label' => 'Related service IDs',
                'type' => 'array_integer',
                'control' => 'csv_integer',
                'post_types' => ['direpair_problem', 'direpair_location', 'direpair_tech', 'direpair_case', 'direpair_price', 'direpair_faq', 'direpair_warranty', 'direpair_article'],
            ],
            'related_technician_ids' => [
                'label' => 'Related technician IDs',
                'type' => 'array_integer',
                'control' => 'csv_integer',
                'post_types' => ['direpair_service', 'direpair_problem', 'direpair_location', 'direpair_case', 'direpair_article'],
            ],
            'faq_ids' => [
                'label' => 'FAQ IDs',
                'type' => 'array_integer',
                'control' => 'csv_integer',
                'post_types' => ['direpair_service', 'direpair_problem', 'direpair_location', 'direpair_price', 'direpair_warranty'],
            ],
            'street_address' => [
                'label' => 'Street address',
                'type' => 'string',
                'post_types' => ['direpair_location'],
            ],
            'city' => [
                'label' => 'City',
                'type' => 'string',
                'post_types' => ['direpair_location'],
            ],
            'region' => [
                'label' => 'Region',
                'type' => 'string',
                'post_types' => ['direpair_location'],
            ],
            'postal_code' => [
                'label' => 'Postal code',
                'type' => 'string',
                'post_types' => ['direpair_location'],
            ],
            'phone' => [
                'label' => 'Phone',
                'type' => 'string',
                'post_types' => ['direpair_location'],
            ],
            'whatsapp' => [
                'label' => 'WhatsApp',
                'type' => 'string',
                'post_types' => ['direpair_location'],
            ],
            'latitude' => [
                'label' => 'Latitude',
                'type' => 'number',
                'post_types' => ['direpair_location'],
            ],
            'longitude' => [
                'label' => 'Longitude',
                'type' => 'number',
                'post_types' => ['direpair_location'],
            ],
            'opening_hours' => [
                'label' => 'Opening hours',
                'type' => 'array_string',
                'control' => 'textarea_list',
                'post_types' => ['direpair_location'],
                'description' => 'One entry per line, for example Monday|09:00|18:00.',
            ],
            'specialties' => [
                'label' => 'Specialties',
                'type' => 'array_string',
                'control' => 'textarea_list',
                'post_types' => ['direpair_tech'],
            ],
            'years_experience' => [
                'label' => 'Years of experience',
                'type' => 'integer',
                'post_types' => ['direpair_tech'],
            ],
            'certifications' => [
                'label' => 'Verified certifications',
                'type' => 'array_string',
                'control' => 'textarea_list',
                'post_types' => ['direpair_tech'],
            ],
            'device_brand' => [
                'label' => 'Device brand',
                'type' => 'string',
                'post_types' => ['direpair_case'],
            ],
            'device_model' => [
                'label' => 'Device model',
                'type' => 'string',
                'post_types' => ['direpair_case'],
            ],
            'reported_symptom' => [
                'label' => 'Reported symptom',
                'type' => 'string',
                'control' => 'textarea',
                'post_types' => ['direpair_case'],
            ],
            'diagnosis_summary' => [
                'label' => 'Diagnosis summary',
                'type' => 'string',
                'control' => 'textarea',
                'post_types' => ['direpair_case'],
            ],
            'repair_action' => [
                'label' => 'Repair action',
                'type' => 'string',
                'control' => 'textarea',
                'post_types' => ['direpair_case'],
            ],
            'repair_outcome' => [
                'label' => 'Repair outcome',
                'type' => 'string',
                'post_types' => ['direpair_case'],
            ],
            'publish_consent' => [
                'label' => 'Customer consent to publish',
                'type' => 'boolean',
                'control' => 'checkbox',
                'default' => false,
                'post_types' => ['direpair_case'],
            ],
            'warranty_duration_days' => [
                'label' => 'Warranty duration days',
                'type' => 'integer',
                'post_types' => ['direpair_warranty'],
            ],
            'warranty_exclusions' => [
                'label' => 'Warranty exclusions',
                'type' => 'array_string',
                'control' => 'textarea_list',
                'post_types' => ['direpair_warranty'],
            ],
            'reviewed_at' => [
                'label' => 'Last technician review date',
                'type' => 'string',
                'control' => 'date',
                'post_types' => ['direpair_article'],
            ],
        ];
    }

    public static function register(): void
    {
        foreach (ContentTypes::postTypes() as $postType => $unused) {
            foreach (self::forPostType($postType) as $key => $definition) {
                register_post_meta($postType, self::key($key), self::registrationArgs($definition));
            }
        }
    }

    /**
     * @return array<string, array{label: string, type: string, control?: string, default?: mixed, post_types?: list<string>, description?: string}>
     */
    public static function forPostType(string $postType): array
    {
        return array_filter(
            self::definitions(),
            static fn (array $definition): bool => in_array($postType, $definition['post_types'] ?? [], true)
        );
    }

    public static function key(string $name): string
    {
        return self::PREFIX.$name;
    }

    /**
     * @param array{type: string, default?: mixed} $definition
     * @return array<string, mixed>
     */
    private static function registrationArgs(array $definition): array
    {
        $type = $definition['type'];
        $default = $definition['default'] ?? self::defaultForType($type);

        if ($type === 'array_string' || $type === 'array_integer') {
            $itemType = $type === 'array_integer' ? 'integer' : 'string';

            return [
                'single' => true,
                'type' => 'array',
                'default' => [],
                'show_in_rest' => [
                    'schema' => [
                        'type' => 'array',
                        'items' => ['type' => $itemType],
                        'default' => [],
                    ],
                ],
                'sanitize_callback' => $itemType === 'integer'
                    ? [self::class, 'sanitizeIntegerArray']
                    : [self::class, 'sanitizeStringArray'],
                'auth_callback' => [self::class, 'canEditMeta'],
            ];
        }

        return [
            'single' => true,
            'type' => $type,
            'default' => $default,
            'show_in_rest' => true,
            'sanitize_callback' => match ($type) {
                'boolean' => [self::class, 'sanitizeBoolean'],
                'integer' => 'absint',
                'number' => [self::class, 'sanitizeNumber'],
                default => 'sanitize_text_field',
            },
            'auth_callback' => [self::class, 'canEditMeta'],
        ];
    }

    public static function canEditMeta(bool $allowed, string $metaKey, int $objectId): bool
    {
        unset($allowed, $metaKey);

        return current_user_can('edit_post', $objectId);
    }

    public static function sanitizeBoolean(mixed $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }

    public static function sanitizeNumber(mixed $value): float
    {
        return is_numeric($value) ? (float) $value : 0.0;
    }

    /**
     * @return list<string>
     */
    public static function sanitizeStringArray(mixed $value): array
    {
        if (! is_array($value)) {
            return [];
        }

        return array_values(array_filter(array_map(
            static fn (mixed $item): string => sanitize_text_field((string) $item),
            $value
        )));
    }

    /**
     * @return list<int>
     */
    public static function sanitizeIntegerArray(mixed $value): array
    {
        if (! is_array($value)) {
            return [];
        }

        return array_values(array_filter(array_map('absint', $value)));
    }

    private static function defaultForType(string $type): mixed
    {
        return match ($type) {
            'boolean' => false,
            'integer' => 0,
            'number' => 0.0,
            'array_string', 'array_integer' => [],
            default => '',
        };
    }
}

