<?php

declare(strict_types=1);

namespace Direpair\Content;

final class AdminTheme
{
    public static function enqueue(): void
    {
        wp_enqueue_style(
            'direpair-admin-theme',
            plugins_url('assets/admin.css', DIREPAIR_CONTENT_FILE),
            [],
            DIREPAIR_CONTENT_VERSION
        );
    }

    public static function bodyClass(string $classes): string
    {
        return trim($classes.' direpair-admin');
    }
}
