<?php

declare(strict_types=1);

namespace Direpair\Content;

final class Publishing
{
    private const CRON_HOOK = 'direpair_dispatch_content_webhook';

    private static bool $guardRunning = false;

    public static function register(): void
    {
        add_action('save_post', [self::class, 'schedulePublishWebhook'], 100, 3);
        add_action('save_post', [self::class, 'enforceProductionGuard'], 110, 3);
        add_action(self::CRON_HOOK, [self::class, 'dispatchWebhook'], 10, 3);

        foreach (array_keys(ContentTypes::postTypes()) as $postType) {
            add_filter('rest_pre_insert_'.$postType, [self::class, 'guardRestPublish'], 10, 2);
        }
    }

    public static function schedulePublishWebhook(int $postId, \WP_Post $post, bool $update): void
    {
        if (! ContentTypes::isManaged($post->post_type) || $post->post_status !== 'publish') {
            return;
        }

        $event = $update ? 'content.updated' : 'content.published';
        $modifiedAt = (string) get_post_modified_time(DATE_ATOM, true, $post);
        $args = [$postId, $event, $modifiedAt];

        if (wp_next_scheduled(self::CRON_HOOK, $args) === false) {
            wp_schedule_single_event(time() + 5, self::CRON_HOOK, $args, true);
        }
    }

    public static function dispatchWebhook(int $postId, string $event, string $modifiedAt): void
    {
        $url = (string) get_option(Settings::WEBHOOK_URL_OPTION, '');
        $secret = (string) get_option(Settings::WEBHOOK_SECRET_OPTION, '');

        if ($url === '' || $secret === '') {
            return;
        }

        $post = get_post($postId);

        if (! $post instanceof \WP_Post || ! ContentTypes::isManaged($post->post_type)) {
            return;
        }

        $timestamp = (string) time();
        $body = wp_json_encode([
            'event' => $event,
            'post_id' => $postId,
            'post_type' => $post->post_type,
            'slug' => $post->post_name,
            'modified_at' => $modifiedAt,
        ]);

        if (! is_string($body)) {
            return;
        }

        $response = wp_safe_remote_post($url, [
            'timeout' => 5,
            'redirection' => 0,
            'sslverify' => true,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-Direpair-Timestamp' => $timestamp,
                'X-Direpair-Signature' => hash_hmac('sha256', $timestamp.'.'.$body, $secret),
            ],
            'body' => $body,
        ]);

        if (is_wp_error($response)) {
            error_log('Direpair content webhook failed: '.$response->get_error_code());
        }
    }

    public static function enforceProductionGuard(int $postId, \WP_Post $post): void
    {
        if (self::$guardRunning || wp_get_environment_type() !== 'production') {
            return;
        }

        if (! ContentTypes::isManaged($post->post_type) || $post->post_status !== 'publish') {
            return;
        }

        $isDemo = (bool) get_post_meta($postId, MetaFields::key('is_demo'), true);

        if (! $isDemo) {
            return;
        }

        self::$guardRunning = true;
        wp_update_post([
            'ID' => $postId,
            'post_status' => 'draft',
        ]);
        update_post_meta($postId, MetaFields::key('noindex'), true);
        self::$guardRunning = false;
    }

    public static function guardRestPublish(mixed $preparedPost, \WP_REST_Request $request): mixed
    {
        if (wp_get_environment_type() !== 'production') {
            return $preparedPost;
        }

        $status = (string) $request->get_param('status');
        $meta = $request->get_param('meta');
        $isDemo = is_array($meta) && ! empty($meta[MetaFields::key('is_demo')]);

        if ($status === 'publish' && $isDemo) {
            return new \WP_Error(
                'direpair_demo_publish_blocked',
                'Demo content cannot be published in production.',
                ['status' => 400]
            );
        }

        return $preparedPost;
    }
}

